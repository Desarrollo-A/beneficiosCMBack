<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['application_name'] = 'Calendar API Test';

$config['api_key'] = 'AIzaSyCCR6Rd3y0E3FgV4iBWTVn_ZtLYMIvZPNw';

$config['service_account'] = "calendario-recepci-n-cm-local@snappy-tine-360922.iam.gserviceaccount.com";

$config['private_key_id'] = "5e9cd8bc7c1c5e83ec31363ebe2a719aa93a0beb";

$config['private_key'] = "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDLJhBIgLpdAa/V\nkuN4Uw+J6EHZ8olIqyNr3Wj3edzReuqwqpKwSZTH06M8KPFn4jL03/kJhjz5txEg\n2jxEomGHggNM1dn7LfIDvqmVoIq3cejybo7a4JZSdSCehGAqkdb1ZVHYXucNNkOH\nvIurKzpvluZY4kLy9m7SFUGFt5lR1lPB/xIsYWlZwZ2mQEAy+CI7gUK201LfuDNg\n1S5GIBP+8x8l4uDGmW5qnJeEpt2Gx0ngXH7CiF1y1Wc6Pv4SzwwuR5b8C/wifiD4\nMfDDu+F+BpFHmzdquonNsSNM29ovbpCuFWzzCbZ3g5Ct3iwn9UqTqbfQpjsorBa/\nUrVagWbXAgMBAAECggEAEUmO7yyNL2b6WJlkZBPlaZ3rJKngBuARZpdz3ENxiB4G\npLwPOZM5Zvvakz8EtAtqvK3mmmni/HkYqwwHPuv2krp8n2g/YYGaa7ko40PDKjM2\nWJMR8wxTnna7LOIk8NpySXWyzk/dJ6Grg3yHAizujxpvRbcTbWuNKLGIXuGt2WnV\n7EcIRyODzkQwvZM6qVGZkwLQpmF5ahVHIz4LfU8Yg7SUzVWFw6WBgrL+TDZT0TMc\nyBAj5vA5uRsjM2sBmaCBqKL1xFDvJyRUXmv0MoT3zL15krdZkBXWXL0C01lr+asP\n4bDEPjU9tJWFEzf3aKVXNXLnGJsQi/yFeoCkr9u7qQKBgQDmKn6MMHjwQw6T2aa3\nHIMdU3jspOlc4LJwwrCUSUYoAm6jPtFJHkTa4sTw4Zs56823w5HbEHaZBPXLq4Qj\nDZRIhBtPZPM+Av6G7EaLyAZ02Is/c3HEZzV5C96UnKNVmyz4/jBP9m8tuv+ODyuM\nCo7oV0qGBImvWoMetuGIVrMUJQKBgQDh80OJ+D7RmW5GihaEnCj2joETgHzzfel5\nVT2tQCnwQ7VY4fVnUGoBdV3Hcq5c+47BeeLU8hkU1fEJYKJL9UvfeavTNsKnQovJ\n18JUNPzhZAL+deGNes2GhG7sIUSfD5hqWLIeRe8jEdayZM/5daL7bFXOKjR0WLzM\n7dvYZJiASwKBgQCV8BbSMn2GXtivPjlZzgwn3YnH90JCi+oShPHNF9LJG5SBadmi\nnUJTqSiMlxus5szzqkZpA9eOpWmNzWTeBOmVN+ImnWfL/N1cfa0TQDHcinhj1EvH\nm0h9W1sbStMoYFcyuTw1yx7wFoKGQ6Glr/caqkrU9T3QatFB//b5/yjXtQKBgQCP\nIjdqs2O4C2YcMWXKY9JfPi7uV7rP1LeOMT18/uSSW5IJ2DpJVFuSyPK7Yh6qsIDi\nd4AGPcc9t7mVoy2syJtj2gPLLSlqI3HCT3e/OEHp1h0/bRWRNnXz/Pj3hKufx5VZ\n6Q4Mt2ih4q8LG2nUMX0poJtKmtnXyk7v0s4t6qvguQKBgQDdx2BGI81lU2JPk/VO\nKXKtE8A23tqKvMBmoJsXy9q6matt3pK+IP/62pwuKdFdbm8WD2mXlccVszHAcI1q\nMEcRc4iKOLCGD1frJVHEABr945FwNnZBNhpk6wHisYb8+TzEXdXb/sD0g4HakfDC\nGdm2mWym87RAE10BNGgqbVgoSw==\n-----END PRIVATE KEY-----\n";

$config['scopes'] = 'https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events';

$config['client_id'] = "161969316544-ou10ee3mktbmp2og21po8rj2eke8ej9t.apps.googleusercontent.com";

$config['client_secret'] = "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";

$config['redirect_uri'] = "postmessage";

$config['token_url'] = "https://oauth2.googleapis.com/token";

$config['bucket'] = "pruebas-conecta-maderas";

?>